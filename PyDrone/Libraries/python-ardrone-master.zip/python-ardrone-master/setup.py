from setuptools import setup, find_packages


setup(
    name='python-ardrone',
    author='Brain Corporation',
    author_email='passot@braincorporation.com',
    url='https://github.com/braincorp/python-ardrone',
    long_description='',
    version='dev',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[])
